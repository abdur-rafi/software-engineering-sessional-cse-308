package customExceptions;

public class ExceedsTotalMarks extends Exception {
    public ExceedsTotalMarks(String message){
        super(message);
    }
}
