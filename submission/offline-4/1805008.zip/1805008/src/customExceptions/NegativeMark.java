package customExceptions;

public class NegativeMark extends Exception {
    public NegativeMark(String message){
        super(message);
    }
}
