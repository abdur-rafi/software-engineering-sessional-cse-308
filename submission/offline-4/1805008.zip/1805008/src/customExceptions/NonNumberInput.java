package customExceptions;

public class NonNumberInput extends Exception {
    public NonNumberInput(String message){
        super(message);
    }
}
