import customExceptions.ExceedsTotalMarks;
import customExceptions.InvalidCredit;
import customExceptions.NegativeMark;

public class Main {
    public static void main(String args[]) throws NegativeMark, ExceedsTotalMarks, InvalidCredit {
//        Grader.calcGrade(123, 3);
    }

}
