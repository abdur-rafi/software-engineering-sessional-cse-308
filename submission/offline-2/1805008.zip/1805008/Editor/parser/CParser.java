package Editor.parser;

public class CParser  implements Parser {
    @Override
    public String getLanguage() {
        return "C";
    }
}
