package Editor.parser;

public class CPPParser  implements Parser {
    @Override
    public String getLanguage() {
        return "Cpp";
    }
}
