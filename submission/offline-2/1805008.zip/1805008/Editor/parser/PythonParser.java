package Editor.parser;

public class PythonParser implements Parser {
    @Override
    public String getLanguage() {
        return "Python";
    }
}

