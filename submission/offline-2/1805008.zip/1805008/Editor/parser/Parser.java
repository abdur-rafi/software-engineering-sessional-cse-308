package Editor.parser;

public interface Parser {
    public String getLanguage();
}
