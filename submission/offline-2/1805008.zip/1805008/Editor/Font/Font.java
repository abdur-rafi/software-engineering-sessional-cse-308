package Editor.Font;

public interface Font {
    public String getFontName();
}
