package Editor.Font;

public class CourierNew  implements Font {
    @Override
    public String getFontName() {
        return "Courier New";
    }
}