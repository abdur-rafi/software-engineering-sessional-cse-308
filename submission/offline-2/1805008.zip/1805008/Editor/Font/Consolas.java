package Editor.Font;

public class Consolas implements Font {
    @Override
    public String getFontName() {
        return "Consolas";
    }
}
