package Editor.Font;

public class Monaco  implements Font {
    @Override
    public String getFontName() {
        return "Monaco";
    }
}
