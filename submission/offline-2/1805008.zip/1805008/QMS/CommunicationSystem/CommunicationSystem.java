package QMS.CommunicationSystem;

import QMS.Part;

public interface CommunicationSystem extends Part {
}
