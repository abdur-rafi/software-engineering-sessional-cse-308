package QMS.Controllers;

import QMS.Part;

public interface Controller  extends Part {
}
