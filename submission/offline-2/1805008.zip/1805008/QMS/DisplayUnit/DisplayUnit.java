package QMS.DisplayUnit;

import QMS.Part;

public interface DisplayUnit extends Part {

}
