package QMS;

public interface Part {
    public String describe();
    public int getCost();
}
