package QMS.Application;

import QMS.Part;

public interface IApplication extends Part {

}
