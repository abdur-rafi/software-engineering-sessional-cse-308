package A;

public interface BlankSeparatorInterface {

    public double calculateSum(String fileName);
}
