package A;

public interface TildeSeparatorInterface {
    public double calculateSum(String fileName);
}
