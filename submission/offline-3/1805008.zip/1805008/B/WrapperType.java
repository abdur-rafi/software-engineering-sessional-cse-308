package B;

public enum WrapperType {
    Cheese,
    Coffee,
    Water,
    Coke,
    OnionRings,
    FrenchFries
}
