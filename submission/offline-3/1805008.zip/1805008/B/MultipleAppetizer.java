package B;

public class MultipleAppetizer extends Exception {

    public MultipleAppetizer(String message){
        super(message);
    }
}
