package B;

public interface Burger {

    public String description();
    public double cost();
    public boolean appetizerAdded();
}
