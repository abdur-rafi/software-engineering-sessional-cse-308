package B.Wrappers;

import B.Burger;

public abstract class BurgerWrapper implements Burger {
    protected Burger burger;
}
