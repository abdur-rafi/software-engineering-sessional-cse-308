package BankingSystem.CustomExceptions;

public class Invalid extends Exception {
    public Invalid(String message) {
        super(message);
    }
}
