package BankingSystem.CustomExceptions;

public class Unauthorized extends Exception {
    public Unauthorized(String message) {
        super(message);
    }
}
