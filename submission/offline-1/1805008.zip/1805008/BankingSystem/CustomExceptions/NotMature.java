package BankingSystem.CustomExceptions;

public class NotMature extends Exception {
    public NotMature(String message) {
        super(message);
    }
}
